#ifndef STATE_POINTER_H
#define STATE_POINTER_H

#include <string>

using namespace std;

typedef string* stringPointer;

#endif