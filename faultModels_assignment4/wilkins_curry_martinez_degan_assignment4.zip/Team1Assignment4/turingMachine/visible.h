#ifndef VISIBLE_H
#define VISIBLE_H

#include <string>

using namespace std;

string visible(string value);

#endif