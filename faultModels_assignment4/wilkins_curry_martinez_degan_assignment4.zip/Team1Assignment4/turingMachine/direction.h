#ifndef DIRECTION_H
#define DIRECTION_H

#include <string>

using namespace std;

typedef char Direction;

#endif